﻿/// <reference path="Cookie.js" />
var CookieThing;
(function (CookieThing) {
    (function (Codec) {
        var Base64 = (function () {
            this.Name = 'Base64';

            this.Encode = function (decodedValue) {
                var encodedValue = decodedValue;
                return encodedValue;
            }

            this.Decode = function (encodedValue) {
                var decodedValue = encodedValue;
                return decodedValue;
            }
        });
    })(Codec || { });
    var Codec = CookieThing.Codec;
})(CookieThing || { });