﻿var CookieThing = {
    Cookie: {
        name: "",
        value: "",
        domain: "",
        hostOnly: false,
        path: "",
        secure: false,
        httpOnly: false,
        session: false,
        expirationDate: 0,
        storeId: ""
    }
}