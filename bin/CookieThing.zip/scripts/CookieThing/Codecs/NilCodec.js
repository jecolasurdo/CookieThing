﻿var CookieThing;
(function (CookieThing) {
    (function (Codecs) {
        Codecs.NilCodec = function () {

            this.FriendlyName = 'None';

            this.Description = 'Performs no conversion';

            this.Encode = function (decodedValue) {
                return decodedValue;
            }

            this.Decode = function (encodedValue) {
                try {
                    return encodedValue;
                }
                catch (err) {
                    return 'The raw value could not be decoded.';
                }
            }

        }
    })(CookieThing.Codecs || (CookieThing.Codecs = {}));
    var Codecs = CookieThing.Codecs;
})(CookieThing || (CookieThing = {}));